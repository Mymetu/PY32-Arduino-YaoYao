/* HAL raised several warnings, ignore them */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"

#if !defined(PY32F040x6) && !defined(PY32F040x8) && !defined(PY32F040x9) && !defined(PY32F040xB) && \
    !defined(PY32F040Cx6) && !defined(PY32F040Cx8) && !defined(PY32F040Cx9) && !defined(PY32F040CxB)
#ifdef AIRC0xx
  #include "py32c0xx_hal_i2s.c"
#elif PY32F0xx
  #include "py32f0xx_hal_i2s.c"
#elif AIR32F1xx
  #include "py32f1xx_hal_i2s.c"
#elif AIRF2xx
  #include "py32f2xx_hal_i2s.c"
#elif AIRF3xx
  #include "py32f3xx_hal_i2s.c"
#elif AIRF4xx
  #include "py32f4xx_hal_i2s.c"
#elif AIRF7xx
  #include "py32f7xx_hal_i2s.c"
#elif AIRG0xx
  #include "py32g0xx_hal_i2s.c"
#elif AIRG4xx
  #include "py32g4xx_hal_i2s.c"
#elif AIRH7xx
  #include "py32h7xx_hal_i2s.c"
#elif AIRL0xx
  #include "py32l0xx_hal_i2s.c"
#elif AIRL1xx
  #include "py32l1xx_hal_i2s.c"
#elif AIRWLxx
  #include "py32wlxx_hal_i2s.c"
#endif
#endif
#pragma GCC diagnostic pop
