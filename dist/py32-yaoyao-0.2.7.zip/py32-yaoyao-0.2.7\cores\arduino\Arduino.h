/*
  Arduino.h - Main include file for the Arduino SDK
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef Arduino_h
#define Arduino_h

#ifndef GCC_VERSION
#define GCC_VERSION (__GNUC__ * 10000 \
                     + __GNUC_MINOR__ * 100 \
                     + __GNUC_PATCHLEVEL__)
#endif
#if GCC_VERSION < 60300
  #error "GCC version 6.3 or higher is required"
#endif

#ifdef __IN_ECLIPSE__
  #include "SrcWrapper.h"
#endif

#include "wiring.h"

#ifdef __cplusplus
  #include "WString.h"
  #include "HardwareSerial.h"
  #include "Tone.h"
  #include "WSerial.h"
  #include "Comparator.h"

  // Convenience frequency literals for sketches.
  // Example: 250_kHz, 1_MHz
  constexpr unsigned long long operator""_kHz(unsigned long long v) { return v * 1000ULL; }
  constexpr unsigned long long operator""_MHz(unsigned long long v) { return v * 1000000ULL; }
#endif

/* sketch */

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus
// Weak empty variant initialization function.
// May be redefined by variant files.
extern void initVariant() __attribute__((weak));

extern void setup(void) ;
extern void loop(void) ;

// Returns true when the NRST/PF2 option byte selects reset mode.
// Returns false when NRST is configured as GPIO.
// On unsupported MCUs/variants, returns true.
bool isReset(void);

void yield(void);
#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

// Include pins variant
#include "pins_arduino.h"

#endif // Arduino_h
