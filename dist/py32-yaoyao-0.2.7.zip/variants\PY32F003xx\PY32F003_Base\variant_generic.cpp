/*
 *******************************************************************************
 * Copyright (c) 2023, AirM2M
 * All rights reserved.
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */
#if defined (PY32F003x4) || defined(PY32F003x6) || defined (PY32F003x8)
#include "pins_arduino.h"

// Digital PinName array
const PinName digitalPin[] = {
    PA_0,  // D0/A0
    PA_1,  // D1/A1
    PA_2,  // D2/A2
    PA_3,  // D3/A3
    PA_4,  // D4/A4
    PA_5,  // D5/A5
    PA_6,  // D6/A6
    PA_7,  // D7/A7
    PA_8,  // D8
    PA_9,  // D9
    PA_10, // D10
    PA_11, // D11
    PA_12, // D12
    PA_13, // D13
    PA_14, // D14
    PA_15, // D15
    PB_0,  // D16/A8
    PB_1,  // D17/A9
    PB_2,  // D18
    PB_3,  // D19
    PB_4,  // D20
    PB_5,  // D21
    PB_6,  // D22
    PB_7,  // D23
    PB_8,  // D24
    PB_9,  // D25
    PB_10, // D26
    PB_11, // D27
    PB_12, // D28
    PB_13, // D29
    PB_14, // D30
    PB_15, // D31
    PF_0,  // D32
    PF_1,  // D33
    PF_6,  // D34
    PF_7,  // D35
    PF_4,  // D36
    PF_2,  // D37 (requires NRST option byte set to GPIO)
};

// Analog (Ax) pin number array
const uint32_t analogInputPin[] = {
    0,  // A0,  PA0
    1,  // A1,  PA1
    2,  // A2,  PA2
    3,  // A3,  PA3
    4,  // A4,  PA4
    5,  // A5,  PA5
    6,  // A6,  PA6
    7,  // A7,  PA7
    16, // A8,  PB0
    17  // A9,  PB1
};

#endif /* ARDUINO_GENERIC_* */
